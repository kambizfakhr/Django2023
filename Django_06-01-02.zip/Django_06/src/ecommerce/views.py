from django.http import HttpResponse
from django.shortcuts import render
from .forms import ContactForm, LoginForm, RegisterForm
from django.contrib.auth import authenticate, login, get_user_model
from django.shortcuts import redirect

def home_page(request):
    context = {
        "title": "صفحه اصلی",
        "store_name" : "فروشگاه لباس"
    }
    return render(request, "index.html", context)


def home_page_old(request):
    go_to_about= "<a href='/about'>برو به  صفحه درباره ما</a>"
    return HttpResponse(go_to_about)

def about_page(request):
    return HttpResponse('about us page of my project')

def contact_page(request):
    contact_form = ContactForm(request.POST or None)
    context = {
        "title": "تماس با ما",
        "content" : "صفحه تماس با ما",
        "form":contact_form
    }

    if contact_form.is_valid():
        result = contact_form.cleaned_data
        print(result)
        print(result["email"])

    return render(request, 'contact/view.html', context)

def login_page(request):
    form = LoginForm(request.POST or None)
    context = {
        "form": form
        }
    if form.is_valid():
        print(form.cleaned_data)
        userName = form.cleaned_data.get("userName")
        password = form.cleaned_data.get("password")
        user = authenticate(request, username=userName, password=password)
        if user is not None:
            login(request,user)
            context["form"] = LoginForm()
            return redirect('/')
        else:
            print("error")
   
    return render(request, "signin.html", context)
#get user model
User = get_user_model()

def register_page(request):
     form = RegisterForm(request.POST or None)
     context = {
        "form": form
     }
     if form.is_valid():
        print(form.cleaned_data)
        userName = form.cleaned_data.get("userName")
        password = form.cleaned_data.get("password")
        email = form.cleaned_data.get("email")
        new_user = User.objects.create_user(username=userName, email=email, password=password,)
        print(new_user)
     return render(request, "register.html", context)